package com.java.sample;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class Solution {
	public static void main(String[] a){
		List<String> blocks = new ArrayList<String>();
		blocks.add("5");
		blocks.add("-2");
		blocks.add("4");
		blocks.add("Z");
		blocks.add("X");
		blocks.add("9");
		blocks.add("+");
		blocks.add("+");
		Stack<Integer> st = new Stack<Integer>();
		int tscore =0,cscore=0;
		for(int i=0; i<blocks.size();i++){
			String str=blocks.get(i);
			try{
				cscore = Integer.parseInt(str);
				st.push(cscore);
				tscore+=cscore;
			}catch(Exception e){
				if(str.equals("Z")){
					if(!st.isEmpty()){
						int x=st.pop();
						tscore-=x;
					}
				}else if(str.equals("X")){
					if(!st.isEmpty()){
						cscore=(2*st.peek());
						st.push(cscore);
						tscore+=cscore;
					}
				}else if(str.equals("+")){
					if(!st.isEmpty()){
						int stlen=st.size();
						cscore=st.get(stlen-1)+st.get(stlen-2);
						st.push(cscore);
						tscore+=cscore;
					}
				}
			}
			cscore=0;
		}
	}
}
