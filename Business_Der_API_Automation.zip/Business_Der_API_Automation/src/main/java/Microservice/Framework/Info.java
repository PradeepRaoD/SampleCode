package Microservice.Framework;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "memberId", "callingApp", "timestamp", "transactionId", "effDtInd", "srcElgOdo", "srcPCPOdo",
		"bldElgOdo", "bldPCPOdo", "rulesFiredOdo" })
public class Info {

	@JsonProperty("memberId")
	private MemberId memberId;
	@JsonProperty("callingApp")
	private String callingApp;
	@JsonProperty("timestamp")
	private String timestamp;
	@JsonProperty("transactionId")
	private String transactionId;
	@JsonProperty("effDtInd")
	private String effDtInd;
	@JsonProperty("srcElgOdo")
	private String srcElgOdo;
	@JsonProperty("srcPCPOdo")
	private String srcPCPOdo;
	@JsonProperty("bldElgOdo")
	private String bldElgOdo;
	@JsonProperty("bldPCPOdo")
	private String bldPCPOdo;
	@JsonProperty("rulesFiredOdo")
	private String rulesFiredOdo;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("memberId")
	public MemberId getMemberId() {
		return memberId;
	}

	@JsonProperty("memberId")
	public void setMemberId(MemberId memberId) {
		this.memberId = memberId;
	}

	@JsonProperty("callingApp")
	public String getCallingApp() {
		return callingApp;
	}

	@JsonProperty("callingApp")
	public void setCallingApp(String callingApp) {
		this.callingApp = callingApp;
	}

	@JsonProperty("timestamp")
	public String getTimestamp() {
		return timestamp;
	}

	@JsonProperty("timestamp")
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	@JsonProperty("transactionId")
	public String getTransactionId() {
		return transactionId;
	}

	@JsonProperty("transactionId")
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	@JsonProperty("effDtInd")
	public String getEffDtInd() {
		return effDtInd;
	}

	@JsonProperty("effDtInd")
	public void setEffDtInd(String effDtInd) {
		this.effDtInd = effDtInd;
	}

	@JsonProperty("srcElgOdo")
	public String getSrcElgOdo() {
		return srcElgOdo;
	}

	@JsonProperty("srcElgOdo")
	public void setSrcElgOdo(String srcElgOdo) {
		this.srcElgOdo = srcElgOdo;
	}

	@JsonProperty("srcPCPOdo")
	public String getSrcPCPOdo() {
		return srcPCPOdo;
	}

	@JsonProperty("srcPCPOdo")
	public void setSrcPCPOdo(String srcPCPOdo) {
		this.srcPCPOdo = srcPCPOdo;
	}

	@JsonProperty("bldElgOdo")
	public String getBldElgOdo() {
		return bldElgOdo;
	}

	@JsonProperty("bldElgOdo")
	public void setBldElgOdo(String bldElgOdo) {
		this.bldElgOdo = bldElgOdo;
	}

	@JsonProperty("bldPCPOdo")
	public String getBldPCPOdo() {
		return bldPCPOdo;
	}

	@JsonProperty("bldPCPOdo")
	public void setBldPCPOdo(String bldPCPOdo) {
		this.bldPCPOdo = bldPCPOdo;
	}

	@JsonProperty("rulesFiredOdo")
	public String getRulesFiredOdo() {
		return rulesFiredOdo;
	}

	@JsonProperty("rulesFiredOdo")
	public void setRulesFiredOdo(String rulesFiredOdo) {
		this.rulesFiredOdo = rulesFiredOdo;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}