package Microservice.Framework;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "provID", "covTyp", "pcpStartDt", "pcpStopDt", "provContrID", "adrSeqNbr", "productCd", "mktTypCd",
		"provMktNbr", "ipaNbr", "spclCd", "pcpTypCd", "tinNbr", "tinSufxCd", "tinPrefxCd", "npiNbr", "npiState",
		"npiZipCd", "npiCity", "pcpInd", "pcpUpdtCd", "pcpRndmCd", "pcpRndmInd", "pcpRadius", "pcpZipCd", "pcpZipCdExt",
		"pcpStatus", "pcpErrCd", "pcpName", "areaCD", "phoneNbr", "tciTableNumber", "rulePkgKey", "uhpInd", "errType",
		"errCd", "errMessage" })
public class Provider {

	@JsonProperty("provID")
	private String provID;
	@JsonProperty("covTyp")
	private String covTyp;
	@JsonProperty("pcpStartDt")
	private String pcpStartDt;
	@JsonProperty("pcpStopDt")
	private String pcpStopDt;
	@JsonProperty("provContrID")
	private String provContrID;
	@JsonProperty("adrSeqNbr")
	private String adrSeqNbr;
	@JsonProperty("productCd")
	private String productCd;
	@JsonProperty("mktTypCd")
	private String mktTypCd;
	@JsonProperty("provMktNbr")
	private String provMktNbr;
	@JsonProperty("ipaNbr")
	private String ipaNbr;
	@JsonProperty("spclCd")
	private String spclCd;
	@JsonProperty("pcpTypCd")
	private String pcpTypCd;
	@JsonProperty("tinNbr")
	private String tinNbr;
	@JsonProperty("tinSufxCd")
	private String tinSufxCd;
	@JsonProperty("tinPrefxCd")
	private String tinPrefxCd;
	@JsonProperty("npiNbr")
	private String npiNbr;
	@JsonProperty("npiState")
	private String npiState;
	@JsonProperty("npiZipCd")
	private String npiZipCd;
	@JsonProperty("npiCity")
	private String npiCity;
	@JsonProperty("pcpInd")
	private String pcpInd;
	@JsonProperty("pcpUpdtCd")
	private String pcpUpdtCd;
	@JsonProperty("pcpRndmCd")
	private String pcpRndmCd;
	@JsonProperty("pcpRndmInd")
	private String pcpRndmInd;
	@JsonProperty("pcpRadius")
	private String pcpRadius;
	@JsonProperty("pcpZipCd")
	private String pcpZipCd;
	@JsonProperty("pcpZipCdExt")
	private String pcpZipCdExt;
	@JsonProperty("pcpStatus")
	private String pcpStatus;
	@JsonProperty("pcpErrCd")
	private String pcpErrCd;
	@JsonProperty("pcpName")
	private String pcpName;
	@JsonProperty("areaCD")
	private String areaCD;
	@JsonProperty("phoneNbr")
	private String phoneNbr;
	@JsonProperty("tciTableNumber")
	private String tciTableNumber;
	@JsonProperty("rulePkgKey")
	private String rulePkgKey;
	@JsonProperty("uhpInd")
	private String uhpInd;
	@JsonProperty("errType")
	private String errType;
	@JsonProperty("errCd")
	private String errCd;
	@JsonProperty("errMessage")
	private String errMessage;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("provID")
	public String getProvID() {
		return provID;
	}

	@JsonProperty("provID")
	public void setProvID(String provID) {
		this.provID = provID;
	}

	@JsonProperty("covTyp")
	public String getCovTyp() {
		return covTyp;
	}

	@JsonProperty("covTyp")
	public void setCovTyp(String covTyp) {
		this.covTyp = covTyp;
	}

	@JsonProperty("pcpStartDt")
	public String getPcpStartDt() {
		return pcpStartDt;
	}

	@JsonProperty("pcpStartDt")
	public void setPcpStartDt(String pcpStartDt) {
		this.pcpStartDt = pcpStartDt;
	}

	@JsonProperty("pcpStopDt")
	public String getPcpStopDt() {
		return pcpStopDt;
	}

	@JsonProperty("pcpStopDt")
	public void setPcpStopDt(String pcpStopDt) {
		this.pcpStopDt = pcpStopDt;
	}

	@JsonProperty("provContrID")
	public String getProvContrID() {
		return provContrID;
	}

	@JsonProperty("provContrID")
	public void setProvContrID(String provContrID) {
		this.provContrID = provContrID;
	}

	@JsonProperty("adrSeqNbr")
	public String getAdrSeqNbr() {
		return adrSeqNbr;
	}

	@JsonProperty("adrSeqNbr")
	public void setAdrSeqNbr(String adrSeqNbr) {
		this.adrSeqNbr = adrSeqNbr;
	}

	@JsonProperty("productCd")
	public String getProductCd() {
		return productCd;
	}

	@JsonProperty("productCd")
	public void setProductCd(String productCd) {
		this.productCd = productCd;
	}

	@JsonProperty("mktTypCd")
	public String getMktTypCd() {
		return mktTypCd;
	}

	@JsonProperty("mktTypCd")
	public void setMktTypCd(String mktTypCd) {
		this.mktTypCd = mktTypCd;
	}

	@JsonProperty("provMktNbr")
	public String getProvMktNbr() {
		return provMktNbr;
	}

	@JsonProperty("provMktNbr")
	public void setProvMktNbr(String provMktNbr) {
		this.provMktNbr = provMktNbr;
	}

	@JsonProperty("ipaNbr")
	public String getIpaNbr() {
		return ipaNbr;
	}

	@JsonProperty("ipaNbr")
	public void setIpaNbr(String ipaNbr) {
		this.ipaNbr = ipaNbr;
	}

	@JsonProperty("spclCd")
	public String getSpclCd() {
		return spclCd;
	}

	@JsonProperty("spclCd")
	public void setSpclCd(String spclCd) {
		this.spclCd = spclCd;
	}

	@JsonProperty("pcpTypCd")
	public String getPcpTypCd() {
		return pcpTypCd;
	}

	@JsonProperty("pcpTypCd")
	public void setPcpTypCd(String pcpTypCd) {
		this.pcpTypCd = pcpTypCd;
	}

	@JsonProperty("tinNbr")
	public String getTinNbr() {
		return tinNbr;
	}

	@JsonProperty("tinNbr")
	public void setTinNbr(String tinNbr) {
		this.tinNbr = tinNbr;
	}

	@JsonProperty("tinSufxCd")
	public String getTinSufxCd() {
		return tinSufxCd;
	}

	@JsonProperty("tinSufxCd")
	public void setTinSufxCd(String tinSufxCd) {
		this.tinSufxCd = tinSufxCd;
	}

	@JsonProperty("tinPrefxCd")
	public String getTinPrefxCd() {
		return tinPrefxCd;
	}

	@JsonProperty("tinPrefxCd")
	public void setTinPrefxCd(String tinPrefxCd) {
		this.tinPrefxCd = tinPrefxCd;
	}

	@JsonProperty("npiNbr")
	public String getNpiNbr() {
		return npiNbr;
	}

	@JsonProperty("npiNbr")
	public void setNpiNbr(String npiNbr) {
		this.npiNbr = npiNbr;
	}

	@JsonProperty("npiState")
	public String getNpiState() {
		return npiState;
	}

	@JsonProperty("npiState")
	public void setNpiState(String npiState) {
		this.npiState = npiState;
	}

	@JsonProperty("npiZipCd")
	public String getNpiZipCd() {
		return npiZipCd;
	}

	@JsonProperty("npiZipCd")
	public void setNpiZipCd(String npiZipCd) {
		this.npiZipCd = npiZipCd;
	}

	@JsonProperty("npiCity")
	public String getNpiCity() {
		return npiCity;
	}

	@JsonProperty("npiCity")
	public void setNpiCity(String npiCity) {
		this.npiCity = npiCity;
	}

	@JsonProperty("pcpInd")
	public String getPcpInd() {
		return pcpInd;
	}

	@JsonProperty("pcpInd")
	public void setPcpInd(String pcpInd) {
		this.pcpInd = pcpInd;
	}

	@JsonProperty("pcpUpdtCd")
	public String getPcpUpdtCd() {
		return pcpUpdtCd;
	}

	@JsonProperty("pcpUpdtCd")
	public void setPcpUpdtCd(String pcpUpdtCd) {
		this.pcpUpdtCd = pcpUpdtCd;
	}

	@JsonProperty("pcpRndmCd")
	public String getPcpRndmCd() {
		return pcpRndmCd;
	}

	@JsonProperty("pcpRndmCd")
	public void setPcpRndmCd(String pcpRndmCd) {
		this.pcpRndmCd = pcpRndmCd;
	}

	@JsonProperty("pcpRndmInd")
	public String getPcpRndmInd() {
		return pcpRndmInd;
	}

	@JsonProperty("pcpRndmInd")
	public void setPcpRndmInd(String pcpRndmInd) {
		this.pcpRndmInd = pcpRndmInd;
	}

	@JsonProperty("pcpRadius")
	public String getPcpRadius() {
		return pcpRadius;
	}

	@JsonProperty("pcpRadius")
	public void setPcpRadius(String pcpRadius) {
		this.pcpRadius = pcpRadius;
	}

	@JsonProperty("pcpZipCd")
	public String getPcpZipCd() {
		return pcpZipCd;
	}

	@JsonProperty("pcpZipCd")
	public void setPcpZipCd(String pcpZipCd) {
		this.pcpZipCd = pcpZipCd;
	}

	@JsonProperty("pcpZipCdExt")
	public String getPcpZipCdExt() {
		return pcpZipCdExt;
	}

	@JsonProperty("pcpZipCdExt")
	public void setPcpZipCdExt(String pcpZipCdExt) {
		this.pcpZipCdExt = pcpZipCdExt;
	}

	@JsonProperty("pcpStatus")
	public String getPcpStatus() {
		return pcpStatus;
	}

	@JsonProperty("pcpStatus")
	public void setPcpStatus(String pcpStatus) {
		this.pcpStatus = pcpStatus;
	}

	@JsonProperty("pcpErrCd")
	public String getPcpErrCd() {
		return pcpErrCd;
	}

	@JsonProperty("pcpErrCd")
	public void setPcpErrCd(String pcpErrCd) {
		this.pcpErrCd = pcpErrCd;
	}

	@JsonProperty("pcpName")
	public String getPcpName() {
		return pcpName;
	}

	@JsonProperty("pcpName")
	public void setPcpName(String pcpName) {
		this.pcpName = pcpName;
	}

	@JsonProperty("areaCD")
	public String getAreaCD() {
		return areaCD;
	}

	@JsonProperty("areaCD")
	public void setAreaCD(String areaCD) {
		this.areaCD = areaCD;
	}

	@JsonProperty("phoneNbr")
	public String getPhoneNbr() {
		return phoneNbr;
	}

	@JsonProperty("phoneNbr")
	public void setPhoneNbr(String phoneNbr) {
		this.phoneNbr = phoneNbr;
	}

	@JsonProperty("tciTableNumber")
	public String getTciTableNumber() {
		return tciTableNumber;
	}

	@JsonProperty("tciTableNumber")
	public void setTciTableNumber(String tciTableNumber) {
		this.tciTableNumber = tciTableNumber;
	}

	@JsonProperty("rulePkgKey")
	public String getRulePkgKey() {
		return rulePkgKey;
	}

	@JsonProperty("rulePkgKey")
	public void setRulePkgKey(String rulePkgKey) {
		this.rulePkgKey = rulePkgKey;
	}

	@JsonProperty("uhpInd")
	public String getUhpInd() {
		return uhpInd;
	}

	@JsonProperty("uhpInd")
	public void setUhpInd(String uhpInd) {
		this.uhpInd = uhpInd;
	}

	@JsonProperty("errType")
	public String getErrType() {
		return errType;
	}

	@JsonProperty("errType")
	public void setErrType(String errType) {
		this.errType = errType;
	}

	@JsonProperty("errCd")
	public String getErrCd() {
		return errCd;
	}

	@JsonProperty("errCd")
	public void setErrCd(String errCd) {
		this.errCd = errCd;
	}

	@JsonProperty("errMessage")
	public String getErrMessage() {
		return errMessage;
	}

	@JsonProperty("errMessage")
	public void setErrMessage(String errMessage) {
		this.errMessage = errMessage;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}