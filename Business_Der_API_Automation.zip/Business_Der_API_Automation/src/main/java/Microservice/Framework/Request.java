package Microservice.Framework;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "info", "sourceData", "buildData", "rulesFired" })
public class Request {

	@JsonProperty("info")
	private Info info;
	@JsonProperty("sourceData")
	private SourceData sourceData;
	@JsonProperty("buildData")
	private BuildData buildData;
	@JsonProperty("rulesFired")
	private List<RulesFired> rulesFired = null;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("info")
	public Info getInfo() {
		return info;
	}

	@JsonProperty("info")
	public void setInfo(Info info) {
		this.info = info;
	}

	@JsonProperty("sourceData")
	public SourceData getSourceData() {
		return sourceData;
	}

	@JsonProperty("sourceData")
	public void setSourceData(SourceData sourceData) {
		this.sourceData = sourceData;
	}

	@JsonProperty("buildData")
	public BuildData getBuildData() {
		return buildData;
	}

	@JsonProperty("buildData")
	public void setBuildData(BuildData buildData) {
		this.buildData = buildData;
	}

	@JsonProperty("rulesFired")
	public List<RulesFired> getRulesFired() {
		return rulesFired;
	}

	@JsonProperty("rulesFired")
	public void setRulesFired(List<RulesFired> rulesFired) {
		this.rulesFired = rulesFired;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}