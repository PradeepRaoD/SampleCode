package Microservice.Framework;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "sbscrRelTypCd", "depnCd", "policyNbr", "mktStNbr", "mbrBthDt", "mbrGdrCd", "pstCd", "pstCdExt",
		"pseudoPCPTypCd" })
public class SrcMember {

	@JsonProperty("sbscrRelTypCd")
	private String sbscrRelTypCd;
	@JsonProperty("depnCd")
	private String depnCd;
	@JsonProperty("policyNbr")
	private String policyNbr;
	@JsonProperty("mktStNbr")
	private String mktStNbr;
	@JsonProperty("mbrBthDt")
	private String mbrBthDt;
	@JsonProperty("mbrGdrCd")
	private String mbrGdrCd;
	@JsonProperty("pstCd")
	private String pstCd;
	@JsonProperty("pstCdExt")
	private String pstCdExt;
	@JsonProperty("pseudoPCPTypCd")
	private String pseudoPCPTypCd;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("sbscrRelTypCd")
	public String getSbscrRelTypCd() {
		return sbscrRelTypCd;
	}

	@JsonProperty("sbscrRelTypCd")
	public void setSbscrRelTypCd(String sbscrRelTypCd) {
		this.sbscrRelTypCd = sbscrRelTypCd;
	}

	@JsonProperty("depnCd")
	public String getDepnCd() {
		return depnCd;
	}

	@JsonProperty("depnCd")
	public void setDepnCd(String depnCd) {
		this.depnCd = depnCd;
	}

	@JsonProperty("policyNbr")
	public String getPolicyNbr() {
		return policyNbr;
	}

	@JsonProperty("policyNbr")
	public void setPolicyNbr(String policyNbr) {
		this.policyNbr = policyNbr;
	}

	@JsonProperty("mktStNbr")
	public String getMktStNbr() {
		return mktStNbr;
	}

	@JsonProperty("mktStNbr")
	public void setMktStNbr(String mktStNbr) {
		this.mktStNbr = mktStNbr;
	}

	@JsonProperty("mbrBthDt")
	public String getMbrBthDt() {
		return mbrBthDt;
	}

	@JsonProperty("mbrBthDt")
	public void setMbrBthDt(String mbrBthDt) {
		this.mbrBthDt = mbrBthDt;
	}

	@JsonProperty("mbrGdrCd")
	public String getMbrGdrCd() {
		return mbrGdrCd;
	}

	@JsonProperty("mbrGdrCd")
	public void setMbrGdrCd(String mbrGdrCd) {
		this.mbrGdrCd = mbrGdrCd;
	}

	@JsonProperty("pstCd")
	public String getPstCd() {
		return pstCd;
	}

	@JsonProperty("pstCd")
	public void setPstCd(String pstCd) {
		this.pstCd = pstCd;
	}

	@JsonProperty("pstCdExt")
	public String getPstCdExt() {
		return pstCdExt;
	}

	@JsonProperty("pstCdExt")
	public void setPstCdExt(String pstCdExt) {
		this.pstCdExt = pstCdExt;
	}

	@JsonProperty("pseudoPCPTypCd")
	public String getPseudoPCPTypCd() {
		return pseudoPCPTypCd;
	}

	@JsonProperty("pseudoPCPTypCd")
	public void setPseudoPCPTypCd(String pseudoPCPTypCd) {
		this.pseudoPCPTypCd = pseudoPCPTypCd;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}