package Microservice.Framework;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "cnsmId", "partnNbr", "srcCd", "lgcySrcId", "transId", "transSetId", "transFlId", "sbscrId",
		"ssn" })
public class MemberId {

	@JsonProperty("cnsmId")
	private String cnsmId;
	@JsonProperty("partnNbr")
	private String partnNbr;
	@JsonProperty("srcCd")
	private String srcCd;
	@JsonProperty("lgcySrcId")
	private String lgcySrcId;
	@JsonProperty("transId")
	private String transId;
	@JsonProperty("transSetId")
	private String transSetId;
	@JsonProperty("transFlId")
	private String transFlId;
	@JsonProperty("sbscrId")
	private String sbscrId;
	@JsonProperty("ssn")
	private String ssn;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("cnsmId")
	public String getCnsmId() {
		return cnsmId;
	}

	@JsonProperty("cnsmId")
	public void setCnsmId(String cnsmId) {
		this.cnsmId = cnsmId;
	}

	@JsonProperty("partnNbr")
	public String getPartnNbr() {
		return partnNbr;
	}

	@JsonProperty("partnNbr")
	public void setPartnNbr(String partnNbr) {
		this.partnNbr = partnNbr;
	}

	@JsonProperty("srcCd")
	public String getSrcCd() {
		return srcCd;
	}

	@JsonProperty("srcCd")
	public void setSrcCd(String srcCd) {
		this.srcCd = srcCd;
	}

	@JsonProperty("lgcySrcId")
	public String getLgcySrcId() {
		return lgcySrcId;
	}

	@JsonProperty("lgcySrcId")
	public void setLgcySrcId(String lgcySrcId) {
		this.lgcySrcId = lgcySrcId;
	}

	@JsonProperty("transId")
	public String getTransId() {
		return transId;
	}

	@JsonProperty("transId")
	public void setTransId(String transId) {
		this.transId = transId;
	}

	@JsonProperty("transSetId")
	public String getTransSetId() {
		return transSetId;
	}

	@JsonProperty("transSetId")
	public void setTransSetId(String transSetId) {
		this.transSetId = transSetId;
	}

	@JsonProperty("transFlId")
	public String getTransFlId() {
		return transFlId;
	}

	@JsonProperty("transFlId")
	public void setTransFlId(String transFlId) {
		this.transFlId = transFlId;
	}

	@JsonProperty("sbscrId")
	public String getSbscrId() {
		return sbscrId;
	}

	@JsonProperty("sbscrId")
	public void setSbscrId(String sbscrId) {
		this.sbscrId = sbscrId;
	}

	@JsonProperty("ssn")
	public String getSsn() {
		return ssn;
	}

	@JsonProperty("ssn")
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}