package Microservice.Framework;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Request_Builder {
	public static String value;
    public static Request_Builder serviceRequestBuilder; 
	public static Request request;
	public static String jsonString;
    
	/*
	 * Use Static block to load the .xls file. So that this is loaded only once.
	 */
	
	public  String requestpayload(int columno) throws IOException {

		/*
		 * Use Singleton design pattern while creating a instance.
		 */
		MemberId memberId = new MemberId();
		Request request = new Request();
		Info info = new Info();
		SourceData sourceData = new SourceData();
		BuildData buildData = new BuildData();
		SrcMember srcMember = new SrcMember();
		SrcProvider srcProvider = new SrcProvider();
		SrcCoverage srcCoverage = new SrcCoverage();
		BldMember bldMember = new BldMember();
		Provider provider = new Provider();
		Coverage coverage = new Coverage();
		RulesFired rulesFired = new RulesFired();
		/*
		 * Use Singleton design pattern while creating a instance.
		 */
		
		List<SrcCoverage> coverageData = new ArrayList<SrcCoverage>();
		List<SrcProvider> providerData = new ArrayList<SrcProvider>();
		List<Coverage> buildcoverageData = new ArrayList<Coverage>();
		List<Provider> buildproviderData = new ArrayList<Provider>();
		List<RulesFired> rulesdata = new ArrayList<RulesFired>();

		ObjectMapper objectMapper = new ObjectMapper();

		memberId.setCnsmId(readfromExcel(2, columno));
		memberId.setPartnNbr(readfromExcel(3, columno));
		memberId.setSrcCd(readfromExcel(4, columno));
		memberId.setLgcySrcId(readfromExcel(5, columno));
		memberId.setTransId(readfromExcel(6, columno));
		memberId.setTransSetId(readfromExcel(7, columno));
		memberId.setTransFlId(readfromExcel(8, columno));
		memberId.setSbscrId(readfromExcel(9, columno));
		memberId.setSsn(readfromExcel(10, columno));

		info.setCallingApp(readfromExcel(11, columno));
		info.setTimestamp(readfromExcel(12, columno));
		info.setTransactionId(readfromExcel(13, columno));
		info.setEffDtInd(readfromExcel(14, columno));
		info.setSrcElgOdo(readfromExcel(15, columno));
		info.setSrcPCPOdo(readfromExcel(16, columno));
		info.setBldElgOdo(readfromExcel(17, columno));
		info.setBldPCPOdo(readfromExcel(18, columno));
		info.setRulesFiredOdo(readfromExcel(19, columno));

		srcMember.setSbscrRelTypCd(readfromExcel(22, columno));
		srcMember.setDepnCd(readfromExcel(23, columno));
		srcMember.setPolicyNbr(readfromExcel(24, columno));
		srcMember.setMktStNbr(readfromExcel(25, columno));
		srcMember.setMbrBthDt(readfromExcel(26, columno));
		srcMember.setMbrGdrCd(readfromExcel(27, columno));
		srcMember.setPstCd(readfromExcel(28, columno));
		srcMember.setPstCdExt(readfromExcel(29, columno));
		srcMember.setPseudoPCPTypCd(readfromExcel(30, columno));

		srcProvider.setProvID(readfromExcel(32, columno));
		srcProvider.setCovTyp(readfromExcel(33, columno));
		srcProvider.setPcpStartDt(readfromExcel(34, columno));
		srcProvider.setPcpStopDt(readfromExcel(35, columno));
		srcProvider.setProvContrID(readfromExcel(36, columno));
		srcProvider.setAdrSeqNbr(readfromExcel(37, columno));
		srcProvider.setProductCd(readfromExcel(38, columno));
		srcProvider.setMktTypCd(readfromExcel(39, columno));
		srcProvider.setProvMktNbr(readfromExcel(40, columno));
		srcProvider.setIpaNbr(readfromExcel(41, columno));
		srcProvider.setSpclCd(readfromExcel(42, columno));
		srcProvider.setPcpTypCd(readfromExcel(43, columno));
		srcProvider.setTinNbr(readfromExcel(44, columno));
		srcProvider.setTinSufxCd(readfromExcel(45, columno));
		srcProvider.setTinPrefxCd(readfromExcel(46, columno));
		srcProvider.setNpiNbr(readfromExcel(47, columno));
		srcProvider.setNpiState(readfromExcel(48, columno));
		srcProvider.setNpiZipCd(readfromExcel(49, columno));
		srcProvider.setNpiCity(readfromExcel(50, columno));
		srcProvider.setPcpInd(readfromExcel(51, columno));
		srcProvider.setPcpUpdtCd(readfromExcel(52, columno));
		srcProvider.setPcpRndmCd(readfromExcel(53, columno));
		srcProvider.setPcpRndmInd(readfromExcel(54, columno));
		srcProvider.setPcpRadius(readfromExcel(55, columno));
		srcProvider.setPcpZipCd(readfromExcel(56, columno));
		srcProvider.setPcpZipCdExt(readfromExcel(57, columno));
		srcProvider.setPcpStatus(readfromExcel(58, columno));
		srcProvider.setPcpErrCd(readfromExcel(59, columno));
		srcProvider.setPcpName(readfromExcel(60, columno));
		srcProvider.setAreaCD(readfromExcel(61, columno));
		srcProvider.setPhoneNbr(readfromExcel(62, columno));
		srcProvider.setTciTableNumber(readfromExcel(63, columno));
		srcProvider.setRulePkgKey(readfromExcel(64, columno));
		srcProvider.setUhpInd(readfromExcel(65, columno));
		srcProvider.setErrType(readfromExcel(66, columno));
		srcProvider.setErrCd(readfromExcel(67, columno));
		srcProvider.setErrMessage(readfromExcel(68, columno));

		srcCoverage.setProductCd(readfromExcel(70, columno));
		srcCoverage.setCovTyp(readfromExcel(71, columno));
		srcCoverage.setMktStNbr(readfromExcel(72, columno));
		srcCoverage.setMktTypCd(readfromExcel(73, columno));
		srcCoverage.setCovStartDt(readfromExcel(74, columno));
		srcCoverage.setCovStopDt(readfromExcel(75, columno));
		srcCoverage.setPolicyNbr(readfromExcel(76, columno));
		srcCoverage.setCovLvlCd(readfromExcel(77, columno));
		srcCoverage.setStateOfIssue(readfromExcel(78, columno));
		srcCoverage.setPlnVarCd(readfromExcel(79, columno));
		srcCoverage.setRptCd(readfromExcel(80, columno));
		srcCoverage.setCesGrpNbr(readfromExcel(81, columno));

		bldMember.setSbscrRelTypCd(readfromExcel(84, columno));
		bldMember.setDepnCd(readfromExcel(85, columno));
		bldMember.setPolicyNbr(readfromExcel(86, columno));
		bldMember.setMktStNbr(readfromExcel(87, columno));
		bldMember.setMbrBthDt(readfromExcel(88, columno));
		bldMember.setMbrGdrCd(readfromExcel(89, columno));
		bldMember.setPstCd(readfromExcel(90, columno));
		bldMember.setPstCdExt(readfromExcel(91, columno));
		bldMember.setPseudoPCPTypCd(readfromExcel(92, columno));

		provider.setProvID(readfromExcel(94, columno));
		provider.setCovTyp(readfromExcel(95, columno));
		provider.setPcpStartDt(readfromExcel(96, columno));
		provider.setPcpStopDt(readfromExcel(97, columno));
		provider.setProvContrID(readfromExcel(98, columno));
		provider.setAdrSeqNbr(readfromExcel(99, columno));
		provider.setProductCd(readfromExcel(100, columno));
		provider.setMktTypCd(readfromExcel(101, columno));
		provider.setProvMktNbr(readfromExcel(102, columno));
		provider.setIpaNbr(readfromExcel(103, columno));
		provider.setSpclCd(readfromExcel(104, columno));
		provider.setPcpTypCd(readfromExcel(105, columno));
		provider.setTinNbr(readfromExcel(106, columno));
		provider.setTinSufxCd(readfromExcel(107, columno));
		provider.setTinPrefxCd(readfromExcel(108, columno));
		provider.setNpiNbr(readfromExcel(109, columno));
		provider.setNpiState(readfromExcel(110, columno));
		provider.setNpiZipCd(readfromExcel(111, columno));
		provider.setNpiCity(readfromExcel(112, columno));
		provider.setPcpInd(readfromExcel(113, columno));
		provider.setPcpUpdtCd(readfromExcel(114, columno));
		provider.setPcpRndmCd(readfromExcel(115, columno));
		provider.setPcpRndmInd(readfromExcel(116, columno));
		provider.setPcpRadius(readfromExcel(117, columno));
		provider.setPcpZipCd(readfromExcel(118, columno));
		provider.setPcpZipCdExt(readfromExcel(119, columno));
		provider.setPcpStatus(readfromExcel(120, columno));
		provider.setPcpErrCd(readfromExcel(121, columno));
		provider.setPcpName(readfromExcel(122, columno));
		provider.setAreaCD(readfromExcel(123, columno));
		provider.setPhoneNbr(readfromExcel(124, columno));
		provider.setTciTableNumber(readfromExcel(125, columno));
		provider.setRulePkgKey(readfromExcel(126, columno));
		provider.setUhpInd(readfromExcel(127, columno));
		provider.setErrType(readfromExcel(128, columno));
		provider.setErrCd(readfromExcel(129, columno));
		provider.setErrMessage(readfromExcel(130, columno));

		coverage.setProductCd(readfromExcel(132, columno));
		coverage.setCovTyp(readfromExcel(133, columno));
		coverage.setMktStNbr(readfromExcel(134, columno));
		coverage.setMktTypCd(readfromExcel(135, columno));
		coverage.setCovStartDt(readfromExcel(136, columno));
		coverage.setCovStopDt(readfromExcel(137, columno));
		coverage.setPolicyNbr(readfromExcel(138, columno));
		coverage.setCovLvlCd(readfromExcel(139, columno));
		coverage.setStateOfIssue(readfromExcel(140, columno));
		coverage.setPlnVarCd(readfromExcel(141, columno));
		coverage.setRptCd(readfromExcel(142, columno));
		coverage.setCesGrpNbr(readfromExcel(143, columno));

		rulesFired.setRuleId(readfromExcel(145, columno));
		rulesdata.add(rulesFired);

		info.setMemberId(memberId);
		sourceData.setSrcMember(srcMember);
		coverageData.add(srcCoverage);
		sourceData.setSrcCoverage(coverageData);
		providerData.add(srcProvider);
		sourceData.setSrcProvider((providerData));
		buildData.setBldMember(bldMember);
		buildcoverageData.add(coverage);
		buildData.setCoverage(buildcoverageData);

		buildproviderData.add(provider);
		buildData.setProvider(buildproviderData);

		request.setInfo(info);
		request.setSourceData(sourceData);
		request.setBuildData(buildData);
		request.setRulesFired(rulesdata);

		jsonString = objectMapper.writeValueAsString(request);
		return jsonString;
	}

	private String readfromExcel(int row, int column) throws IOException {
		//The next 2 statements should be in static block. 
		InputStream ExcelFileToRead = new FileInputStream(".//src//Params.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(ExcelFileToRead);
		
		try {
			value = wb.getSheetAt(0).getRow(row).getCell(column).toString();
			if (value != null) {
				if (value.endsWith(".0")) {
					value = value.replaceAll(".0", "");
				}
				value = value.replaceAll("-", "");
			}
		} 
		//Catch Exception which this try block actually will throw.
		//Do e.printStackTrace() always and see if this can be put in a Logger. (OR) put this in sysout. 
		catch (Exception e) {
			value = "";
		}
		return value;
	}

	public static Request_Builder getInstance() {
	    if(serviceRequestBuilder == null)
	    	serviceRequestBuilder = new Request_Builder ();
		return serviceRequestBuilder;
	}
}