package Microservice.Framework;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "bldMember", "provider", "coverage" })
public class BuildData {

	@JsonProperty("bldMember")
	private BldMember bldMember;
	@JsonProperty("provider")
	private List<Provider> provider = null;
	@JsonProperty("coverage")
	private List<Coverage> coverage = null;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("bldMember")
	public BldMember getBldMember() {
		return bldMember;
	}

	@JsonProperty("bldMember")
	public void setBldMember(BldMember bldMember) {
		this.bldMember = bldMember;
	}

	@JsonProperty("provider")
	public List<Provider> getProvider() {
		return provider;
	}

	@JsonProperty("provider")
	public void setProvider(List<Provider> provider) {
		this.provider = provider;
	}

	@JsonProperty("coverage")
	public List<Coverage> getCoverage() {
		return coverage;
	}

	@JsonProperty("coverage")
	public void setCoverage(List<Coverage> coverage) {
		this.coverage = coverage;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}