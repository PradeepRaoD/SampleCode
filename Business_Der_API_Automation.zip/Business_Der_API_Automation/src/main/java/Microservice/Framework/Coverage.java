package Microservice.Framework;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "productCd", "covTyp", "mktStNbr", "mktTypCd", "covStartDt", "covStopDt", "policyNbr", "covLvlCd",
		"stateOfIssue", "plnVarCd", "rptCd", "cesGrpNbr" })
public class Coverage {

	@JsonProperty("productCd")
	private String productCd;
	@JsonProperty("covTyp")
	private String covTyp;
	@JsonProperty("mktStNbr")
	private String mktStNbr;
	@JsonProperty("mktTypCd")
	private String mktTypCd;
	@JsonProperty("covStartDt")
	private String covStartDt;
	@JsonProperty("covStopDt")
	private String covStopDt;
	@JsonProperty("policyNbr")
	private String policyNbr;
	@JsonProperty("covLvlCd")
	private String covLvlCd;
	@JsonProperty("stateOfIssue")
	private String stateOfIssue;
	@JsonProperty("plnVarCd")
	private String plnVarCd;
	@JsonProperty("rptCd")
	private String rptCd;
	@JsonProperty("cesGrpNbr")
	private String cesGrpNbr;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("productCd")
	public String getProductCd() {
		return productCd;
	}

	@JsonProperty("productCd")
	public void setProductCd(String productCd) {
		this.productCd = productCd;
	}

	@JsonProperty("covTyp")
	public String getCovTyp() {
		return covTyp;
	}

	@JsonProperty("covTyp")
	public void setCovTyp(String covTyp) {
		this.covTyp = covTyp;
	}

	@JsonProperty("mktStNbr")
	public String getMktStNbr() {
		return mktStNbr;
	}

	@JsonProperty("mktStNbr")
	public void setMktStNbr(String mktStNbr) {
		this.mktStNbr = mktStNbr;
	}

	@JsonProperty("mktTypCd")
	public String getMktTypCd() {
		return mktTypCd;
	}

	@JsonProperty("mktTypCd")
	public void setMktTypCd(String mktTypCd) {
		this.mktTypCd = mktTypCd;
	}

	@JsonProperty("covStartDt")
	public String getCovStartDt() {
		return covStartDt;
	}

	@JsonProperty("covStartDt")
	public void setCovStartDt(String covStartDt) {
		this.covStartDt = covStartDt;
	}

	@JsonProperty("covStopDt")
	public String getCovStopDt() {
		return covStopDt;
	}

	@JsonProperty("covStopDt")
	public void setCovStopDt(String covStopDt) {
		this.covStopDt = covStopDt;
	}

	@JsonProperty("policyNbr")
	public String getPolicyNbr() {
		return policyNbr;
	}

	@JsonProperty("policyNbr")
	public void setPolicyNbr(String policyNbr) {
		this.policyNbr = policyNbr;
	}

	@JsonProperty("covLvlCd")
	public String getCovLvlCd() {
		return covLvlCd;
	}

	@JsonProperty("covLvlCd")
	public void setCovLvlCd(String covLvlCd) {
		this.covLvlCd = covLvlCd;
	}

	@JsonProperty("stateOfIssue")
	public String getStateOfIssue() {
		return stateOfIssue;
	}

	@JsonProperty("stateOfIssue")
	public void setStateOfIssue(String stateOfIssue) {
		this.stateOfIssue = stateOfIssue;
	}

	@JsonProperty("plnVarCd")
	public String getPlnVarCd() {
		return plnVarCd;
	}

	@JsonProperty("plnVarCd")
	public void setPlnVarCd(String plnVarCd) {
		this.plnVarCd = plnVarCd;
	}

	@JsonProperty("rptCd")
	public String getRptCd() {
		return rptCd;
	}

	@JsonProperty("rptCd")
	public void setRptCd(String rptCd) {
		this.rptCd = rptCd;
	}

	@JsonProperty("cesGrpNbr")
	public String getCesGrpNbr() {
		return cesGrpNbr;
	}

	@JsonProperty("cesGrpNbr")
	public void setCesGrpNbr(String cesGrpNbr) {
		this.cesGrpNbr = cesGrpNbr;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}